package com.mindex.challenge.data;

import java.util.Date;

public class Compensation {
    private Employee employee;
    private int salary;
    private Date effDate;

    public Compensation() {}

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public Date getEffectiveDate() {
        return effDate;
    }

    public void setEffectiveDate(Date effDate) {
        this.effDate = effDate;
    }
}
